package VAMSIAVINASHGUNJIProject;

public class Rhombus extends Quadrilateral {

	protected Rhombus(Integer l, Double a) {
		//Purpose: To find an area and perimeter of Rhombus
		// This takes in input as one side and one angle, which is adjacent angle between two sides.
		
		super(l, l, a);
		
	}
	

}
