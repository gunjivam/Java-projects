package VAMSIAVINASHGUNJIProject;

public class Square extends Quadrilateral {

	public Square(Integer l, Double a) {
		//Purpose: To find area and perimeter of square
		//Square takes in only one input of side, and Angle which is always 90.
		
		super(l, l, a);
		
	}

	

}
