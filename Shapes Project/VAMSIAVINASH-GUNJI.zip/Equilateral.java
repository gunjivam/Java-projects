package VAMSIAVINASHGUNJIProject;

public class Equilateral extends Triangles {

	public Equilateral(Double s1) {
		//Purpose: To find area and perimeter of Equilateral triangle
		// This Equilateral class takes on one side as input since it has all sides equal.
		super(s1, s1 ,s1);
		
	}

}
