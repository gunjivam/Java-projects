package VAMSIAVINASHGUNJIProject;

public interface shapes {

public Double getarea();	//Purpose: To get the area of the given figure
	
public Double getPerimeter();	//Purpose: To get the perimeter of the given figure

}
