package VAMSIAVINASHGUNJIProject;

public class Scalene extends Triangles{

	public Scalene(Double s1, Double s2, Double s3) {
		//Purpose: to find the area and perimeter of triangle
		// This takes in all three sides as inputs.
		super(s1, s2, s3);
		
	}

}
