package VAMSIAVINASHGUNJIProject;

public class Rectangle extends Quadrilateral{

	public Rectangle(Integer l, Integer b, Double a) {
		//Purpose: To find area and perimeter of Rectangle
		// This takes three inputs two as sides and one as angle which is 90.
		super(l, b, a);
		
	}

}
