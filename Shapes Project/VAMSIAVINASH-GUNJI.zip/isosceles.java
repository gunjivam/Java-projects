package VAMSIAVINASHGUNJIProject;

public class isosceles extends Triangles {

	public isosceles(Double s1, Double s2) {
		//Purpose: To find area and perimeter of isosceles triangle
		// this Class takes in two sides s1 and s2 as input, where s1 is repeated side.
		super(s1, s1, s2);
		
	}

}
